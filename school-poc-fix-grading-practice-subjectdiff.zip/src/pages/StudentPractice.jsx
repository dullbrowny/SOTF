import { useEffect, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import { useDemoData } from '../demoData.jsx'

export default function StudentPractice() {
  const { dataset } = useDemoData()
  const [data, setData] = useState({ items: [] })
  const [progress, setProgress] = useState(58)

  const fetchData = async () => {
    const d = await api.getPractice()
    setData(d && d.items ? d : { items: [] })
  }

  useEffect(() => { fetchData() }, [dataset])

  const answer = (idx, correct) => {
    if (correct) setProgress(p => Math.min(100, p + 3))
    else setProgress(p => Math.max(0, p - 1))
  }

  return (
    <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Personalized Practice</h2>
          <div className="badge">Dataset: {dataset.toUpperCase()}</div>
          <div className="badge">Weak topic: Linear Equations – {progress}%</div>
        </div>
        {data.items.length === 0 && <div className="card">No practice items found for this dataset.</div>}
        {data.items.map((q, i) => (
          <div className="card" key={i}>
            <div><strong>Q{i+1}.</strong> {q.question}</div>
            <div className="row" style={{marginTop: 8, flexWrap: 'wrap'}}>
              {q.options.map((opt, j) => (
                <button className="btn secondary" key={j} onClick={()=>answer(i, opt===q.answer)}>{opt}</button>
              ))}
            </div>
            {q.hint && <div className="badge">{q.hint}</div>}
          </div>
        ))}
      </div>
      <div className="grid">
        <KPI label="Mastery now" value={`${progress}%`} delta="+9pp in 3 weeks"/>
        <KPI label="Adaptive difficulty" value="On"/>
        <KPI label="Engagement" value="1.7× baseline"/>
      </div>
    </div>
  )
}
