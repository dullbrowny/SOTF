// src/api/mockApi.js
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

function datasetBase() {
  const ds = localStorage.getItem("dataset") || "g8";
  return `/api/datasets/${ds}`;
}

async function safeFetchJson(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export async function getQuestionsBySubjectTopic(subject = "math", topic = "") {
  await delay(200);
  const sub = String(subject || "math").toLowerCase().trim();
  const top = String(topic || "").toLowerCase().replace(/\s+/g, "-").trim();
  const base = datasetBase();

  // 1) /<subject>/<topic>/questions.json (if topic provided)
  if (top) {
    const topicUrl = `${base}/${sub}/${top}/questions.json`;
    const topicData = await safeFetchJson(topicUrl);
    if (topicData && topicData.items) return { ...topicData, _source: topicUrl };
  }

  // 2) /<subject>/questions.json
  const subjectUrl = `${base}/${sub}/questions.json`;
  const subjectData = await safeFetchJson(subjectUrl);
  if (subjectData && subjectData.items) return { ...subjectData, _source: subjectUrl };

  // 3) /questions.json
  const fallbackUrl = `${base}/questions.json`;
  const fb = await safeFetchJson(fallbackUrl);
  if (fb && fb.items) return { ...fb, _source: fallbackUrl };

  return { items: [], _source: "(none)" };
}

async function get(path) {
  await delay(200);
  const url = `${datasetBase()}${path}`;
  const data = await safeFetchJson(url);
  return data ?? {};
}

export const api = {
  getQuestions: (subject, topic) => getQuestionsBySubjectTopic(subject, topic),
  getGradingBatch: () => get("/grading.json"),
  getPractice: () => get("/practice.json"),
  getTutorScript: () => get("/tutor.json"),
  getAdminMetrics: () => get("/admin.json"),
  getParentDigest: () => get("/parent.json"),
};
