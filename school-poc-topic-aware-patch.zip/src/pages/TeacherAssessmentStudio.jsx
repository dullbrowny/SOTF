// src/pages/TeacherAssessmentStudio.jsx
import { useEffect, useMemo, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import Loading from '../components/Loading.jsx'
import { useDemoData } from '../demoData.jsx'

const TOPICS = {
  math: ["Linear Equations", "Quadratic Equations"],
  science: ["Atoms", "Chemical Reactions"]
}

function normSubject(s) { return String(s || 'Math').toLowerCase() }

export default function TeacherAssessmentStudio() {
  const { dataset, setDataset } = useDemoData()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [subject, setSubject] = useState('Math')
  const [grade, setGrade] = useState(dataset.replace('g','') || '8')
  const [topic, setTopic] = useState('Linear Equations')

  // keep topic list in sync with subject
  const topicOptions = useMemo(() => TOPICS[normSubject(subject)] || TOPICS.math, [subject])

  useEffect(() => {
    if (!topicOptions.includes(topic)) setTopic(topicOptions[0])
  }, [topicOptions])

  const generate = async () => {
    setLoading(true)
    const q = await api.getQuestions(subject, topic)
    setData(q)
    setLoading(false)
  }

  // Regenerate when dataset, subject, or topic change
  useEffect(() => { generate() }, [dataset, subject, topic])

  const onGradeChange = (e) => {
    const g = e.target.value
    setGrade(g)
    const next = `g${g}`
    if (next !== dataset) setDataset(next)
  }

  return (
    <div className="grid" style={{gridTemplateColumns: '1fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Assessment Studio</h2>
          <div className="grid" style={{gridTemplateColumns: '1fr 1fr 1fr'}}>
            <div>
              <label>Grade</label>
              <select value={grade} onChange={onGradeChange}>
                <option>7</option><option>8</option><option>9</option>
              </select>
            </div>
            <div>
              <label>Subject</label>
              <select value={subject} onChange={e=>setSubject(e.target.value)}>
                <option>Math</option><option>Science</option>
              </select>
            </div>
            <div>
              <label>Topic</label>
              <select className="input" value={topic} onChange={e=>setTopic(e.target.value)}>
                {topicOptions.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <div className="row" style={{marginTop: 12}}>
            <button className="btn" onClick={generate}>Generate with AI</button>
            <span className="badge">Uses scripted output</span>
          </div>
        </div>

        {loading && <Loading text="Generating items…"/>}

        {data && <div className="card">
          <h3>Generated Items</h3>
          <div className="badge">Loaded from: {data._source}</div>
          <table className="table mono">
            <thead><tr><th>#</th><th>Question</th><th>Answer</th><th>Variant 1</th><th>Variant 2</th><th>Rubric</th></tr></thead>
            <tbody>
              {data.items?.map((it, i) => (
                <tr key={i}>
                  <td>{i+1}</td>
                  <td>{it.question}</td>
                  <td>{it.answer}</td>
                  <td>{it.variant_1}</td>
                  <td>{it.variant_2}</td>
                  <td>{it.rubric}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>}
      </div>

      <div className="grid">
        <KPI label="Questions generated" value={data?.items?.length ?? '—'} delta="~0.2s elapsed"/>
        <KPI label="Teacher time saved" value="3.0 hrs / week"/>
        <KPI label="Curriculum alignment" value={`NCERT G${grade} • ${subject} • ${topic}`}/>
      </div>
    </div>
  )
}
