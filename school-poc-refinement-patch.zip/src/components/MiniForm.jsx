export default function MiniForm({ children }) {
  return <div className="row" style={{ gap: 12, flexWrap: 'wrap', alignItems: 'end' }}>{children}</div>;
}
