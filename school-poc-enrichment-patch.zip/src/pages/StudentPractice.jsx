// src/pages/StudentPractice.jsx
import { useEffect, useMemo, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import ProgressBar from '../components/ProgressBar.jsx'
import { useDemoData } from '../demoData.jsx'

export default function StudentPractice() {
  const { dataset } = useDemoData()
  const [data, setData] = useState({ items: [] })
  const [progress, setProgress] = useState(58)
  const [index, setIndex] = useState(0)
  const [correct, setCorrect] = useState(null)
  const [streak, setStreak] = useState(0)

  const fetchData = async () => {
    const d = await api.getPractice()
    setData(d && d.items ? d : { items: [] })
    setIndex(0); setCorrect(null)
  }
  useEffect(() => { fetchData() }, [dataset])

  const items = data.items || []
  const q = items[index] || null
  const answered = useMemo(()=> index, [index])

  const choose = (opt) => {
    if (!q) return
    const ok = String(opt) === String(q.answer)
    setCorrect(ok)
    setProgress(p => Math.max(0, Math.min(100, p + (ok ? 3 : -1))))
    setStreak(s => ok ? s+1 : 0)
    setTimeout(()=> {
      setIndex(i => Math.min(items.length-1, i+1))
      setCorrect(null)
    }, 700)
  }

  return (
    <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Personalized Practice</h2>
          <div className="row" style={{gap:12}}>
            <div className="badge">Dataset: {dataset.toUpperCase()}</div>
            <div className="badge">Weak topic: Linear Equations – {progress}%</div>
            <div className="badge">Streak: {streak}</div>
          </div>
          <ProgressBar value={answered} max={Math.max(1, items.length)} label={`${answered}/${items.length}`} />
        </div>

        {!q && <div className="card">No practice items found.</div>}
        {q && <div className="card">
          <div><strong>Q{index+1}.</strong> {q.question}</div>
          <div className="row" style={{marginTop: 8, flexWrap: 'wrap'}}>
            {q.options.map((opt, j) => {
              const sel = String(opt)===String(q.answer);
              const cls = (correct===null) ? 'btn secondary' : (sel ? 'btn' : 'btn secondary');
              return <button className={cls} key={j} onClick={()=>choose(opt)}>{opt}</button>
            })}
          </div>
          <div style={{marginTop:8}}>
            <div className="badge">{q.hint || 'Consider distributing or factoring where needed.'}</div>
            {correct!==null && <div className="badge">{correct ? '✓ Correct — great job!' : '✕ Not quite — try the next one.'}</div>}
          </div>
        </div>}
      </div>
      <div className="grid">
        <KPI label="Mastery now" value={`${progress}%`} delta="+9pp in 3 weeks"/>
        <KPI label="Adaptive difficulty" value={streak>=3 ? 'Increasing' : 'Stable'}/>
        <KPI label="Engagement" value="1.7× baseline"/>
      </div>
    </div>
  )
}
