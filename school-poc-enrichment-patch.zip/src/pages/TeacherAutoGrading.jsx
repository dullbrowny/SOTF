// src/pages/TeacherAutoGrading.jsx
import { useEffect, useMemo, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import Loading from '../components/Loading.jsx'
import Sparkline from '../components/Sparkline.jsx'
import ProgressBar from '../components/ProgressBar.jsx'
import { useDemoData } from '../demoData.jsx'

function synthesize(d) {
  const n = d?.submissions ?? 32;
  return Array.from({length: n}).map((_,i)=> ({
    id: i+1,
    student: ['Arjun','Meera','Kavya','Dev','Zoya','Irfan','Nina','Omar','Lila','Rohit'][i%10] + ' ' + (7+(i%4)),
    score: 50 + ((i*7)%51),
    confidence: 60 + ((i*11)%37),
    status: (i%11===0) ? 'needs-review' : 'auto-graded'
  }));
}

export default function TeacherAutoGrading() {
  const { dataset } = useDemoData()
  const [data, setData] = useState(null)
  const [grading, setGrading] = useState(false)

  const fetchData = async () => {
    const d = await api.getGradingBatch()
    setData(d || {})
  }
  useEffect(() => { fetchData() }, [dataset])

  const rows = useMemo(() => synthesize(data), [data])
  const confSeries = useMemo(() => rows.map(r=>r.confidence), [rows])
  const reviewed = rows.filter(r=>r.status==='needs-review').length

  const gradeAll = async () => {
    setGrading(true)
    await new Promise(r=>setTimeout(r, 900))
    setGrading(false)
  }

  return (
    <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Auto-Grading</h2>
          <div className="row">
            <button className="btn" onClick={gradeAll}>Grade All</button>
            <span className="badge">Simulated</span>
          </div>
        </div>

        {grading && <Loading text="Grading submissions…"/>}

        <div className="card">
          <h3>Results</h3>
          <div className="row" style={{gap: 24, alignItems:'center'}}>
            <div className="badge">{rows.length} submissions</div>
            <div className="badge">{reviewed} needs review</div>
            <div className="badge">AI confidence avg: {Math.round(confSeries.reduce((a,b)=>a+b,0)/confSeries.length)}%</div>
          </div>
          <div style={{marginTop:12}}>
            <Sparkline values={confSeries} />
          </div>
          <table className="table" style={{marginTop:12}}>
            <thead><tr><th>#</th><th>Student</th><th>Score</th><th>Confidence</th><th>Status</th><th>Evidence</th></tr></thead>
            <tbody>
              {rows.slice(0,8).map(r=> (
                <tr key={r.id}>
                  <td>{r.id}</td>
                  <td>{r.student}</td>
                  <td>{r.score}%</td>
                  <td>{r.confidence}%</td>
                  <td>{r.status==='needs-review' ? 'Needs review' : 'Auto-graded'}</td>
                  <td><button className="btn secondary" onClick={()=>alert('Rubric: 1 pt setup, 1 pt method, 1 pt answer\nEvidence: steps match key.')}>Show</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="grid">
        <KPI label="Grading time" value="6h → 2h" delta="-4h/week"/>
        <KPI label="Feedback latency" value="< 5 min (MCQ)"/>
        <div className="card">
          <div className="kpi">
            <div className="label">Queue cleared</div>
            <div className="value">{Math.round(((rows.length-reviewed)/Math.max(1,rows.length))*100)}%</div>
            <ProgressBar value={rows.length-reviewed} max={rows.length} />
          </div>
        </div>
        <KPI label="Human-in-loop" value="Enabled for essays"/>
      </div>
    </div>
  )
}
