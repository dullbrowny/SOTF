// src/components/ProgressBar.jsx
export default function ProgressBar({ value = 0, max = 100, label }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className="progress">
      <div className="progress-bar" style={{ width: pct + '%' }} />
      {label && <div className="progress-label">{label}</div>}
    </div>
  );
}
