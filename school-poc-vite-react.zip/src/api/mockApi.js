
function datasetBase() {
  const ds = localStorage.getItem('dataset') || 'g8'
  return `/api/datasets/${ds}`
}

const delay = (ms) => new Promise(res => setTimeout(res, ms))

async function get(path, dataset='default') {
  await delay(400) // simulate latency
  const res = await fetch(`/api/${dataset}${path}`)
  if (!res.ok) throw new Error(`Mock fetch failed: ${path}`)
  return res.json()
}


import { useContext } from 'react'
import { DemoDataContext } from '../App.jsx'

export const useApi = () => {
  const { dataset } = useContext(DemoDataContext)
  return {
    getQuestions: () => get('/questions.json', dataset),
    getGradingBatch: () => get('/grading.json', dataset),
    getPractice: () => get('/practice.json', dataset),
    getTutorScript: () => get('/tutor.json', dataset),
    getAdminMetrics: () => get('/admin.json', dataset),
    getParentDigest: () => get('/parent.json', dataset),
  }
}

  getQuestions: () => get('/questions.json'),
  getGradingBatch: () => get('/grading.json'),
  getPractice: () => get('/practice.json'),
  getTutorScript: () => get('/tutor.json'),
  getAdminMetrics: () => get('/admin.json'),
  getParentDigest: () => get('/parent.json'),
}
