import { Routes, Route, NavLink } from 'react-router-dom'
import TeacherAssessmentStudio from './pages/TeacherAssessmentStudio.jsx'
import TeacherAutoGrading from './pages/TeacherAutoGrading.jsx'
import StudentPractice from './pages/StudentPractice.jsx'
import StudentTutorChat from './pages/StudentTutorChat.jsx'
import AdminDashboard from './pages/AdminDashboard.jsx'
import ParentDigest from './pages/ParentDigest.jsx'


import { createContext, useState } from 'react'
export const DemoDataContext = createContext({ dataset: 'default', setDataset: ()=>{} })

import { useDemoData } from './demoData.jsx'


function DatasetSwitcher(){
  const { dataset, setDataset } = useDemoData()
  return (
    <div className="row">
      <span className="badge">Demo data</span>
      <select value={dataset} onChange={e=>setDataset(e.target.value)}>
        <option value="g7">Grade 7</option>
        <option value="g8">Grade 8</option>
        <option value="g9">Grade 9</option>
      </select>
    </div>
  )
}


export default function App() {
  const [dataset, setDataset] = useState('default');
  return (
    <DemoDataContext.Provider value={{ dataset, setDataset }}><div>
      <nav className="nav">
        <div className="inner">
          <div className="row">
            <strong>School of the Future PoC</strong>
            <span className="badge">Demo • Mock Data</span>
          </div>
          
            <select value={dataset} onChange={e=>setDataset(e.target.value)} className="input" style={{maxWidth:150}}>
              <option value="default">Dataset: Default</option>
              <option value="grade7">Dataset: Grade 7</option>
              <option value="grade8">Dataset: Grade 8</option>
              <option value="grade9">Dataset: Grade 9</option>
            </select>

<div className="links">
            <NavLink to="/" end>Assessment</NavLink>
            <NavLink to="/grading">Grading</NavLink>
            <NavLink to="/practice">Practice</NavLink>
            <NavLink to="/tutor">Tutor</NavLink>
            <NavLink to="/admin">Admin</NavLink>
            <NavLink to="/parent">Parent</NavLink>
          </div>
          <DatasetSwitcher />
        </div>
      </nav>
      <div className="container">
        <Routes>
          <Route path="/" element={<TeacherAssessmentStudio />} />
          <Route path="/grading" element={<TeacherAutoGrading />} />
          <Route path="/practice" element={<StudentPractice />} />
          <Route path="/tutor" element={<StudentTutorChat />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/parent" element={<ParentDigest />} />
        </Routes>
      </div>
    </div></DemoDataContext.Provider>
  )
}
