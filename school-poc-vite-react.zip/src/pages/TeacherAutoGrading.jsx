import { useEffect, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import Loading from '../components/Loading.jsx'

export default function TeacherAutoGrading() {
  const [data, setData] = useState(null)
  const [grading, setGrading] = useState(false)

  useEffect(() => {
    api.getGradingBatch().then(setData)
  }, [])

  const gradeAll = async () => {
    setGrading(true)
    await new Promise(r=>setTimeout(r, 900))
    setGrading(false)
  }

  return (
    <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Auto-Grading</h2>
          <div className="row">
            <button className="btn" onClick={gradeAll}>Grade All</button>
            <span className="badge">Simulated</span>
          </div>
        </div>

        {grading && <Loading text="Grading 28 submissions…"/>}

        {data && <div className="card">
          <h3>Results</h3>
          <div className="row" style={{gap: 24}}>
            <div className="badge">27 auto-graded</div>
            <div className="badge">1 needs review</div>
            <div className="badge">AI confidence: 92%</div>
          </div>
          <h4 style={{marginTop: 12}}>Essay Sample Feedback</h4>
          <div className="mono card">
            <strong>Student:</strong> I believe x=4 because 2x+3=11…<br/>
            <strong>AI:</strong> ✔️ Correct setup; explain last step more clearly.
          </div>
        </div>}
      </div>
      <div className="grid">
        <KPI label="Grading time" value="6h → 2h" delta="-4h/week"/>
        <KPI label="Feedback latency" value="< 5 min (MCQ)"/>
        <KPI label="Human-in-loop" value="Enabled for essays"/>
      </div>
    </div>
  )
}
