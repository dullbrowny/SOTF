import { useEffect, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import Loading from '../components/Loading.jsx'

export default function TeacherAssessmentStudio() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [subject, setSubject] = useState('Math')
  const [grade, setGrade] = useState('8')
  const [topic, setTopic] = useState('Linear Equations')

  const generate = async () => {
    setLoading(true)
    const q = await api.getQuestions()
    setData(q)
    setLoading(false)
  }

  useEffect(() => { generate() }, [])

  return (
    <div className="grid" style={{gridTemplateColumns: '1fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Assessment Studio</h2>
          <div className="grid" style={{gridTemplateColumns: '1fr 1fr 1fr'}}>
            <div><label>Grade</label><select value={grade} onChange={e=>setGrade(e.target.value)}><option>7</option><option>8</option><option>9</option></select></div>
            <div><label>Subject</label><select value={subject} onChange={e=>setSubject(e.target.value)}><option>Math</option><option>Science</option></select></div>
            <div><label>Topic</label><input className="input" value={topic} onChange={e=>setTopic(e.target.value)} /></div>
          </div>
          <div className="row" style={{marginTop: 12}}>
            <button className="btn" onClick={generate}>Generate with AI</button>
            <span className="badge">Uses scripted output</span>
          </div>
        </div>

        {loading && <Loading text="Generating items…"/>}

        {data && <div className="card">
          <h3>Generated Items</h3>
          <table className="table mono">
            <thead><tr><th>#</th><th>Question</th><th>Answer</th><th>Variant 1</th><th>Variant 2</th><th>Rubric</th></tr></thead>
            <tbody>
              {data.items.map((it, i) => (
                <tr key={i}>
                  <td>{i+1}</td>
                  <td>{it.question}</td>
                  <td>{it.answer}</td>
                  <td>{it.variant_1}</td>
                  <td>{it.variant_2}</td>
                  <td>{it.rubric}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>}
      </div>

      <div className="grid">
        <KPI label="Questions generated" value={data ? data.items.length : '—'} delta="4.2s elapsed"/>
        <KPI label="Teacher time saved" value="3.0 hrs / week"/>
        <KPI label="Curriculum alignment" value="NCERT G8 • Chapter 2"/>
      </div>
    </div>
  )
}
