
// src/api/mockApi.js
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

function datasetBase() {
  const ds = localStorage.getItem("dataset") || "g8";
  return `/api/datasets/${ds}`;
}

async function safeFetchJson(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

// Subject/topic-aware questions (3-tier)
export async function getQuestionsBySubjectTopic(subject = "math", topic = "") {
  await delay(150);
  const sub = String(subject || "math").toLowerCase().trim();
  const top = String(topic || "").toLowerCase().replace(/\s+/g, "-").trim();
  const base = datasetBase();
  if (top) {
    const topicUrl = `${base}/${sub}/${top}/questions.json`;
    const topicData = await safeFetchJson(topicUrl);
    if (topicData && topicData.items) return { ...topicData, _source: topicUrl };
  }
  const subjectUrl = `${base}/${sub}/questions.json`;
  const subjectData = await safeFetchJson(subjectUrl);
  if (subjectData && subjectData.items) return { ...subjectData, _source: subjectUrl };
  const fallbackUrl = `${base}/questions.json`;
  const fb = await safeFetchJson(fallbackUrl);
  if (fb && fb.items) return { ...fb, _source: fallbackUrl };
  return { items: [], _source: "(none)" };
}

// Practice generator based on subject/topic
export async function generatePractice(subject = "math", topic = "Linear Equations") {
  await delay(120);
  const top = String(topic).replace(/\s+/g, " ");
  const items = Array.from({length: 5}).map((_,i)=>{
    return {
      question: `${i+1}. (${subject} • ${top}) Solve for x: 2x + ${3+i} = ${11+i}`,
      options: [2,3,4,5].map(n=>String(n)),
      answer: "4",
      hint: "Reverse the last operation."
    }
  });
  return { items };
}

// Evidence samples per student id
const evidenceBank = (id) => ({
  question: "Explain why 2x + 3 = 11 leads to x = 4",
  student: [ "I subtracted 3 then divided by 2", "I think x is 5 because 2*5+3=13", "I moved 3 to RHS and divided by 2" ][id%3],
  rubric: [
    { dim: "Setup", score: (id%5?1:0), note: (id%5? "Correct isolation of variable": "Incorrect rearrangement") },
    { dim: "Method", score: (id%2?1:0), note: (id%2? "Valid operations used": "Missing an operation") },
    { dim: "Answer", score: (id%4?1:0), note: (id%4? "Correct final value": "Arithmetic slip at end") },
  ]
});

async function get(path) {
  await delay(120);
  const url = `${datasetBase()}${path}`;
  const data = await safeFetchJson(url);
  return data ?? {};
}

export const api = {
  getQuestions: (subject, topic) => getQuestionsBySubjectTopic(subject, topic),
  getGradingBatch: () => get("/grading.json"),
  getPractice: () => get("/practice.json"),
  getTutorScript: () => get("/tutor.json"),
  getAdminMetrics: () => get("/admin.json"),
  getParentDigest: () => get("/parent.json"),
  generatePractice,
  evidenceBank,
};
