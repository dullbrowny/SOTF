
// src/pages/TeacherAutoGrading.jsx
import { useEffect, useMemo, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import ProgressBar from '../components/ProgressBar.jsx'
import Modal from '../components/Modal.jsx'
import { useDemoData } from '../demoData.jsx'

function synthesize(d) {
  const n = d?.submissions ?? 28;
  return Array.from({length: n}).map((_,i)=> ({
    id: i+1,
    student: ['Arjun','Meera','Kavya','Dev','Zoya','Irfan','Nina','Omar','Lila','Rohit'][i%10] + ' ' + (7+(i%4)),
    score: 50 + ((i*7)%51),
    confidence: 60 + ((i*11)%37),
    status: 'pending'
  }));
}

export default function TeacherAutoGrading() {
  const { dataset } = useDemoData()
  const [rows, setRows] = useState([])
  const [show, setShow] = useState(null) // row id for modal

  const fetchData = async () => {
    const d = await api.getGradingBatch()
    setRows(synthesize(d))
  }
  useEffect(() => { fetchData() }, [dataset])

  const needsReview = rows.filter(r=>r.status==='needs-review').length
  const cleared = rows.filter(r=>r.status!=='pending').length

  const gradeAll = async () => {
    // animate the queue grading
    let i = 0;
    const newRows = [...rows];
    const timer = setInterval(()=>{
      if (i >= newRows.length) { clearInterval(timer); return; }
      const r = newRows[i];
      r.status = (i % 9 === 0) ? 'needs-review' : 'auto-graded';
      r.confidence = r.status==='auto-graded' ? r.confidence : Math.max(55, r.confidence-15);
      setRows([...newRows]);
      i++;
    }, 80);
  }

  const openEvidence = (r) => setShow(r);

  return (
    <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Auto-Grading</h2>
          <div className="row">
            <button className="btn" onClick={gradeAll}>Grade All</button>
            <span className="badge">Simulated</span>
          </div>
        </div>

        <div className="card">
          <h3>Results</h3>
          <div className="row" style={{gap: 24, alignItems:'center'}}>
            <div className="badge">{rows.length} submissions</div>
            <div className="badge">{needsReview} needs review</div>
            <div className="badge">AI confidence avg: {Math.round(rows.reduce((a,b)=>a+b.confidence,0)/Math.max(1,rows.length))}%</div>
          </div>
          <table className="table" style={{marginTop:12}}>
            <thead><tr><th>#</th><th>Student</th><th>Score</th><th>Confidence</th><th>Status</th><th>Evidence</th></tr></thead>
            <tbody>
              {rows.slice(0,12).map(r=> (
                <tr key={r.id}>
                  <td>{r.id}</td>
                  <td>{r.student}</td>
                  <td>{r.score}%</td>
                  <td>{r.confidence}%</td>
                  <td>{r.status==='pending' ? 'Pending' : r.status==='needs-review' ? 'Needs review' : 'Auto-graded'}</td>
                  <td><button className="btn secondary" onClick={()=>openEvidence(r)}>Show</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="grid">
        <KPI label="Grading time" value="6h → 2h" delta="-4h/week"/>
        <KPI label="Feedback latency" value="< 5 min (MCQ)"/>
        <div className="card">
          <div className="kpi">
            <div className="label">Queue cleared</div>
            <div className="value">{Math.round((cleared/Math.max(1,rows.length))*100)}%</div>
            <ProgressBar value={cleared} max={Math.max(1, rows.length)} />
          </div>
        </div>
        <KPI label="Human-in-loop" value="Enabled for essays"/>
      </div>

      <Modal
        open={!!show}
        title={`Evidence • ${show?.student ?? ''}`}
        onClose={()=>setShow(null)}
        actions={null}
      >
        {show && (
          <Evidence id={show.id} status={show.status} />
        )}
      </Modal>
    </div>
  )
}

function Evidence({ id, status }) {
  const ev = api.evidenceBank(id);
  return (
    <div className="mono">
      <div><strong>Question:</strong> {ev.question}</div>
      <div><strong>Student:</strong> {ev.student}</div>
      <div style={{marginTop:8}}><strong>Rubric scoring:</strong></div>
      <table className="table mono">
        <thead><tr><th>Dimension</th><th>Score</th><th>Note</th></tr></thead>
        <tbody>
          {ev.rubric.map((r,i)=>(
            <tr key={i}><td>{r.dim}</td><td>{r.score ? '✓' : '✕'}</td><td>{r.note}</td></tr>
          ))}
        </tbody>
      </table>
      {status==='needs-review' && <div className="badge">Suggested action: flag for teacher review</div>}
      <div className="row" style={{gap:8, marginTop:8}}>
        <button className="btn secondary" onClick={()=>alert('Added comment: Great setup. Tighten final step.')}>Add teacher comment</button>
        <button className="btn" onClick={()=>alert('Regraded with stricter rubric. Score updated.')}>Regrade</button>
      </div>
    </div>
  );
}
