// src/api/mockApi.js
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

function datasetBase() {
  const ds = localStorage.getItem("dataset") || "g8";
  return `/api/datasets/${ds}`;
}

async function safeFetchJson(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) {
      console.warn("Mock fetch non-200:", res.status, url);
      return null;
    }
    return await res.json();
  } catch (e) {
    console.error("Mock fetch error:", url, e);
    return null;
  }
}

export async function getQuestionsBySubject(subject = "math") {
  await delay(200);
  const sub = String(subject || "math").toLowerCase();
  const base = datasetBase();

  // Try subject-scoped first
  const subjectUrl = `${base}/${sub}/questions.json`;
  let data = await safeFetchJson(subjectUrl);
  if (data && data.items) {
    return { ...data, _source: subjectUrl };
  }

  // Fallback to default
  const fallbackUrl = `${base}/questions.json`;
  data = await safeFetchJson(fallbackUrl);
  if (data && data.items) {
    return { ...data, _source: fallbackUrl };
  }

  // Last resort
  return { items: [], _source: "(none)" };
}

async function get(path) {
  await delay(200);
  const url = `${datasetBase()}${path}`;
  const data = await safeFetchJson(url);
  return data ?? {};
}

export const api = {
  getQuestions: (subject) => getQuestionsBySubject(subject),
  getGradingBatch: () => get("/grading.json"),
  getPractice: () => get("/practice.json"),
  getTutorScript: () => get("/tutor.json"),
  getAdminMetrics: () => get("/admin.json"),
  getParentDigest: () => get("/parent.json"),
};
