import { useEffect, useState } from 'react'
import { api } from '../api/mockApi.js'
import { useDemoData } from '../demoData.jsx'

function Bubble({ who, children }) {
  const align = who === 'ai' ? 'flex-start' : 'flex-end'
  return (
    <div style={{display:'flex', justifyContent: align}}>
      <div className="card" style={{maxWidth: 520}}>
        <div className="badge">{who === 'ai' ? 'AI Tutor' : 'You'}</div>
        <div>{children}</div>
      </div>
    </div>
  )
}

export default function StudentTutorChat() {
  const { dataset } = useDemoData()
  const [script, setScript] = useState([])
  const [input, setInput] = useState('I don’t get how to solve 2x + 3 = 11')
  const [step, setStep] = useState(0)
  const [typing, setTyping] = useState(false)

  useEffect(() => { api.getTutorScript().then(setScript) }, [dataset])

  const send = async () => {
    if (!input) return
    setScript(s => [...s, { who: 'user', text: input }])
    setInput('')
    setTyping(true)
    await new Promise(r=>setTimeout(r, 800))
    const ai = [
      { who:'ai', text:'No worries! Let’s break it down: Step 1 – Subtract 3 from both sides. What do you get?' },
      { who:'ai', text:'Great. Now divide both sides by 2. What’s x?' },
      { who:'ai', text:'Exactly — x = 4. Want a similar practice problem?' }
    ][step % 3]
    setScript(s => [...s, ai])
    setStep(s => s + 1)
    setTyping(false)
  }

  return (
    <div className="grid" style={{gridTemplateColumns:'2fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>AI Tutor</h2>
          <div className="badge">Dataset: {dataset.toUpperCase()}</div>
          <div className="badge">Topic: Linear Equations • Confidence: High • Source: NCERT</div>
        </div>
        <div className="grid">
          {script.map((m, i) => <Bubble who={m.who} key={i}>{m.text}</Bubble>)}
          {typing && <Bubble who="ai">Typing…</Bubble>}
        </div>
        <div className="card row" style={{gap:8}}>
          <input className="input" value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask a question…" />
          <button className="btn" onClick={send}>Send</button>
        </div>
      </div>
      <div className="grid">
        <div className="card">
          <div className="kpi">
            <div className="label">Completion without human help</div>
            <div className="value">82%</div>
          </div>
        </div>
        <div className="card">
          <div className="kpi">
            <div className="label">Recommended next</div>
            <div className="value">2-step equations (easy)</div>
          </div>
        </div>
      </div>
    </div>
  )
}
