import { useEffect, useState } from 'react'
import { api } from '../api/mockApi.js'
import KPI from '../components/KPI.jsx'
import Loading from '../components/Loading.jsx'
import { useDemoData } from '../demoData.jsx'

export default function TeacherAutoGrading() {
  const { dataset } = useDemoData()
  const [data, setData] = useState(null)
  const [grading, setGrading] = useState(false)

  const fetchData = () => api.getGradingBatch().then(setData)
  useEffect(fetchData, [dataset])

  const gradeAll = async () => {
    setGrading(true)
    await new Promise(r=>setTimeout(r, 900))
    setGrading(false)
  }

  return (
    <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
      <div className="grid">
        <div className="card">
          <h2>Auto-Grading</h2>
          <div className="row">
            <button className="btn" onClick={gradeAll}>Grade All</button>
            <span className="badge">Simulated</span>
          </div>
        </div>

        {grading && <Loading text="Grading submissions…"/>}

        {data && <div className="card">
          <h3>Results</h3>
          <div className="row" style={{gap: 24}}>
            <div className="badge">{data.auto ?? 0} auto-graded</div>
            <div className="badge">{data.review ?? 0} needs review</div>
            <div className="badge">AI confidence: 92%</div>
          </div>
          {data.essaySample && (<><h4 style={{marginTop: 12}}>Essay Sample Feedback</h4>
          <div className="mono card">
            <strong>Student:</strong> {data.essaySample.student}<br/>
            <strong>AI:</strong> {data.essaySample.feedback}
          </div></>)}
        </div>}
      </div>
      <div className="grid">
        <KPI label="Grading time" value="6h → 2h" delta="-4h/week"/>
        <KPI label="Feedback latency" value="< 5 min (MCQ)"/>
        <KPI label="Human-in-loop" value="Enabled for essays"/>
      </div>
    </div>
  )
}
