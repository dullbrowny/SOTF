const delay = (ms) => new Promise((res) => setTimeout(res, ms));

function datasetBase() {
  const ds = localStorage.getItem("dataset") || "g8";
  return `/api/datasets/${ds}`;
}

async function get(path) {
  await delay(300);
  const res = await fetch(`${datasetBase()}${path}`);
  if (!res.ok) throw new Error(`Mock fetch failed: ${path}`);
  return res.json();
}

// Try subject-specific file first, then fallback to default questions.json
async function getQuestionsBySubject(subject = "math") {
  const sub = String(subject || "math").toLowerCase();
  const base = datasetBase();
  // First try /{subject}/questions.json
  let res = await fetch(`${base}/${sub}/questions.json`);
  if (res.ok) return res.json();
  // Fallback: /questions.json
  res = await fetch(`${base}/questions.json`);
  if (res.ok) return res.json();
  console.error("Questions not found for subject:", sub);
  return { items: [] };
}

export const api = {
  getQuestions: (subject) => getQuestionsBySubject(subject),
  getGradingBatch: () => get("/grading.json"),
  getPractice: () => get("/practice.json"),
  getTutorScript: () => get("/tutor.json"),
  getAdminMetrics: () => get("/admin.json"),
  getParentDigest: () => get("/parent.json"),
};
